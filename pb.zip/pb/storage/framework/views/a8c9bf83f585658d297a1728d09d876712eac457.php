    <?php $__env->startSection('title', 'Отметить как выполненное ' . $phone->name); ?>


<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
            <h1>Отметить заявку <b><?php echo e($phone->name); ?></b></h1>
        <form method="POST" enctype="multipart/form-data"
              action="<?php echo e(route('phone.update', $phone)); ?>">
            <div>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Отметить как выполненное </label>
                    <div class="col-sm-6">
                        <input type="checkbox" class="form-control" name="name" id="name"
                               value="<?php if(isset($price)): ?><?php echo e($price->done); ?><?php endif; ?>">
                    </div>
                </div>
               <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/phone/form.blade.php ENDPATH**/ ?>