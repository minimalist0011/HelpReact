<?php $__env->startSection('title', 'Пожарное оборудование'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1>Противопожарное оборудование</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>#</th>
                <th>Название</th>
                <th>Фото</th>
            </tr>
            <?php $__currentLoopData = $fires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($fire->id); ?></td>
                    <td><?php echo e($fire->name); ?></td>
                    <td><?php echo e($fire->image); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <form action="<?php echo e(route('fire.destroy', $fire)); ?>" method="POST">
                                <a class="btn btn-success" type="button" href="<?php echo e(route('fire.show', $fire)); ?>">Открыть</a>
                                <!--<a class="btn btn-success" type="button" href="#">Skus</a>-->
                                <a class="btn btn-warning" type="button" href="<?php echo e(route('fire.edit', $fire)); ?>">Редактировать</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger" type="submit" value="Удалить"></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <a class="btn btn-success" type="button" href="<?php echo e(route('fire.create')); ?>">Добавить прайс</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/fire/index.blade.php ENDPATH**/ ?>