<?php $__env->startSection('content'); ?>

    <div class="index-contacts-block inner">
        <div class="contacts">
            <div class="name">
                Мы находимся по адресу:
            </div>
            <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($info->adress); ?></p>
            <p><span>Телефон:</span><?php echo e($info->phone); ?></p>
            <p><span>Почта:</span> <?php echo e($info->email); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="contacts-map">
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A22d95a6d71aad035cc4d7566d986c6b569521dde17397648d8d5479761e75ae0&amp;width=100%&amp;height=100%&amp;lang=ru_RU&amp;scroll=false"></script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/contacts.blade.php ENDPATH**/ ?>