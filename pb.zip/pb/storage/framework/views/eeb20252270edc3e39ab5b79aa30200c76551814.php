<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1><?php echo e($phone->name); ?></h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($phone->id); ?></td>
            </tr>
            <tr>
                <td>Имя</td>
                <td><?php echo e($phone->name); ?></td>
            </tr>
            <tr>
                <td>Тип обращения</td>
                <td><?php echo e($phone->type); ?></td>
            </tr>
            <tr>
                <td>Почта</td>
                <td><?php echo e($phone->email); ?></td>
            </tr>
            <tr>
                <td>Телефон</td>
                <td><?php echo e($phone->phone); ?></td>
            </tr>
            <tr>
                <td>Время для связи</td>
                <td><?php echo e($phone->date); ?></td>
            </tr>
            <tr>
                <td>Вид связи</td>
                <td><?php echo e($phone->talk); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/phone/show.blade.php ENDPATH**/ ?>