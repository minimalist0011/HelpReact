<?php $__env->startSection('title', 'Заявки'); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1>Заявки</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>#</th>
                <th>Имя</th>
                <th>Тип обращения</th>
                <th>Почта</th>
                <th>Телефон</th>
                <th>Время для связи</th>
                <th>Вид связи</th>
            </tr>
            <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($phone->id); ?></td>
                    <td><?php echo e($phone->name); ?></td>
                    <td><?php echo e($phone->type); ?></td>
                    <td><?php echo e($phone->email); ?></td>
                    <td><?php echo e($phone->phone); ?></td>
                    <td><?php echo e($phone->date); ?></td>
                    <td><?php echo e($phone->talk); ?></td>

                    <td>
                        <div class="btn-group" role="group">
                            <form action="<?php echo e(route('phone.destroy', $phone)); ?>" method="POST">
                                <a class="btn btn-success" type="button" href="<?php echo e(route('phone.show', $phone)); ?>">Открыть</a>
                                <!--<a class="btn btn-success" type="button" href="#">Skus</a>-->
                                <a class="btn btn-warning" type="button" href="<?php echo e(route('phone.edit', $phone)); ?>">Редактировать</a>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <input class="btn btn-danger" type="submit" value="Удалить"></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/phone/index.blade.php ENDPATH**/ ?>