<?php if(isset($fire)): ?>
    <?php $__env->startSection('title', 'Редактировать оборудование ' . $fire->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Создать оборудование'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <?php if(isset($fire)): ?>
            <h1>Редактировать оборудование <b><?php echo e($fire->name); ?></b></h1>
        <?php else: ?>
            <h1>Добавить оборудование</h1>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data"
              <?php if(isset($fire)): ?>
              action="<?php echo e(route('fire.update', $fire)); ?>"
              <?php else: ?>
              action="<?php echo e(route('fire.store')); ?>"
            <?php endif; ?>
        >
            <div>
                <?php if(isset($fire)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Название</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" id="name"
                               value="<?php if(isset($fire)): ?><?php echo e($fire->name); ?><?php endif; ?>">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Фото</label>
                    <div class="col-sm-6">
                        <input type="file" class="form-control" name="image" id="image"
                               value="<?php if(isset($fire)): ?><?php echo e($fire->image); ?><?php endif; ?>">
                    </div>
                </div>
                <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/fire/form.blade.php ENDPATH**/ ?>