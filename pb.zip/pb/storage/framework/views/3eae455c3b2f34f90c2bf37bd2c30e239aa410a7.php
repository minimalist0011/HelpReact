<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1><?php echo e($fire->name); ?></h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($fire->id); ?></td>
            </tr>
            <tr>
                <td>Название</td>
                <td><?php echo e($fire->name); ?></td>
            </tr>
            <tr>
                <td>Фото</td>
                <td><?php echo e($fire->image); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/fire/show.blade.php ENDPATH**/ ?>