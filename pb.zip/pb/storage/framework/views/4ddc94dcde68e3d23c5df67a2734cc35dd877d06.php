<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <h1><?php echo e($price->name); ?></h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td><?php echo e($price->id); ?></td>
            </tr>
            <tr>
                <td>Название</td>
                <td><?php echo e($price->name); ?></td>
            </tr>
            <tr>
                <td>Прайс</td>
                <td><?php echo e($price->price); ?></td>
            </tr>
            <tr>
                <td>Гарантия</td>
                <td><?php echo e($price->garante); ?></td>
            </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/auth/price/show.blade.php ENDPATH**/ ?>