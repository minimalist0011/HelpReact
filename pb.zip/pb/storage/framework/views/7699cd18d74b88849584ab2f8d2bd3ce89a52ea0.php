<?php $__env->startSection('content'); ?>
    <div class="index-first-block">
        <img src="<?php echo e(asset('storage/video/service2.png')); ?>">
        <div class="text">
            <p class="other">Видеонаблюдение</p>
        </div>
    </div>
    <div class="services-block flex">
        <div class="list">
            <div class="name">
                Виды выполняемых работ
            </div>
            <p>Ниже представлены варианты мест где устанавливаются камеры:</p>
            <div class="flex other">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <img src="<?php echo e(asset("storage/$video->image")); ?>">
                        <p><?php echo e($video->name); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="main-item">
            <img src="<?php echo e(asset('storage/video/image2.png')); ?>">
            <div class="text">
                <div class="name">
                    Предоставляемые виды работ
                </div>
                Наша компания предоставляет возможность реализации установки: автоматического пожаротушения, пожарной сигнализации, внутреннего противопожарного водопровода, монтаж системы оповещения, а так же занимаемся пректированием систем тушения, под каждый заказ.
            </div>
        </div>
    </div>
    <div class="bottom-page-form">
        <div class="name">
            Свяжемся с вами в скором времени
        </div>
        <form method="GET" action="<?php echo e(route('phone')); ?>">
            <div class="flex">
                <input type="text" placeholder="Имя" name="name" id="name" required>
                <select name="type" id="type">
                    <option>Тип обращения</option>
                    <option>Установка видеонаблюдения</option>
                    <option>Установка противопожарной системы</option>
                    <option>Расчет стоимости</option>
                </select>
            </div>
            <div class="flex">
                <input type="text" name="email" id="email" placeholder="Почта">
                <input type="text" name="phone" id="phone" placeholder="Номер телефона" required>
            </div>
            <p>Выберите дату звонка</p>
            <input type="datetime-local" id="localdate" name="date"/>
            <select name="talk" id="talk">
                <option>Выберите как Вам удобно общаться</option>
                <option>Звонок</option>
                <option>Письмо на почту</option>
                <option>WhatsApp</option>
                <option>Viber</option>
            </select>
            <button type="submit">Свяжитесь со мной</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\pb\resources\views/video.blade.php ENDPATH**/ ?>