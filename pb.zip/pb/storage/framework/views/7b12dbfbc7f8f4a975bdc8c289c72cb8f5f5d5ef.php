<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>js/common.js"></script>
</head>
<body>
<header class="header flex">
    <div class="logo">
        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('storage/logo.png')); ?>"></a>
    </div>
    <ul>
        <li><a href="<?php echo e(route('index')); ?>">Главная</a></li>
        <li><a href="<?php echo e(route('price')); ?>">Прайс-лист</a></li>
        <li><a href="<?php echo e(route('contacts')); ?>">Контакты</a></li>
        <li><a href="<?php echo e(route('home')); ?>">Панель администратора</a></li>
    </ul>
    <a class="menu-button"><i class="fa fa-bars"></i></a>
</header>


<div class="container-fluid">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<footer class="footer">
    <div class="flex">
        <div class="logo">
            <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('storage/logo2.png')); ?>"></a>
        </div>
        <ul>
            <li><a href="<?php echo e(route('contacts')); ?>">О нас</a></li>
            <li><a href="<?php echo e(route('contacts')); ?>">Контакты</a></li>
            <li><a href="tel:+7(499)408-72-39">+7 (499) 408-72-39</a></li>
        </ul>
    </div>
    <div class="social">
        <span>Мы в социальных сетях</span>
        <a href="#"><img src="<?php echo e(asset('storage/social1.svg')); ?>"></a>
        <a href="#"><img src="<?php echo e(asset('storage/social2.svg')); ?>"></a>
        <a href="#"><img src="<?php echo e(asset('storage/social3.svg')); ?>"></a>
    </div>
</footer>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\pb\resources\views/layouts/master.blade.php ENDPATH**/ ?>