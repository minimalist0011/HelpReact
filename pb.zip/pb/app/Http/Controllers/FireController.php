<?php

namespace App\Http\Controllers;

use App\Models\Fire;
use Illuminate\Http\Request;

class FireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function index()
    {
        $fires = Fire::get();
        return view('auth.fire.index', compact('fires'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function create()
    {
        return view('auth.fire.form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $params = $request->all();
        Fire::create($params);
        return redirect()->route('fire.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Fire  $fire
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function show(Fire $fire)
    {
        return view('auth.fire.show', compact('fire'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Fire  $fire
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function edit(Fire $fire)
    {
        return view('auth.fire.form', compact('fire'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Fire  $fire
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Fire $fire)
    {
        $params = $request->all();
        $fire->update($params);
        return redirect()->route('fire.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Fire  $fire
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Fire $fire)
    {
        $fire->delete();
        return redirect()->route('fire.index');
    }
}
