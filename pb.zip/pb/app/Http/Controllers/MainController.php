<?php

namespace App\Http\Controllers;

use App\Models\Fire;
use App\Models\Info;
use App\Models\Phone;
use App\Models\Price;
use App\Models\Video;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rules\In;

class MainController extends Controller
{
    public function index() {
        // берем из бд и выводим
        $infos = Info::get();
        return view('index', compact('infos'));
    }

    public function popup(Request $request) {
        $name = $request->name;
        $phone = $request->phone;
        return DB::table('forphones')->insert(['name' => $name, 'phone' => $phone]);
    }

    public function price() {
        $prices = Price::get();
        return view('price', compact('prices'));
    }

    public function contacts(Request $request) {
        // берем из бд и выводим
        $infos = Info::get();
        return view('contacts', compact('infos'));
    }

    public function fire(Request $request) {
        $fires = Fire::get();
        return view('fire', compact('fires'));
    }

    public function video() {
        $videos = Video::get();
        return view('video', compact('videos'));
    }

    public function phone(Request $request) {
        $name = $request->name;
        $type = $request->type;
        $email = $request->email;
        $phone = $request->phone;
        $date = $request->date;
        $talk = $request->talk;
        return DB::table('phones')->insert(['name' => $name, 'type' => $type, 'email' => $email, 'phone' => $phone, 'date' => $date, 'talk' => $talk]);
    }

}
