<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Info extends Model
{
    // поля которые можно заполнять
    protected $fillable = ['adress', 'phone', 'email'];
    use HasFactory;
}
