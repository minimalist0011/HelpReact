<?php

use App\Http\Controllers\MainController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// авторизация/регистрация подключаем модуль
Auth::routes();

// группа маршрутов доступных после регистрации
Route::group([
    'prefix' => 'auth',
], function () {
    // регистрируем сразу все маршруты из каждого контроллера
    Route::resource('price', \App\Http\Controllers\PriceController::class);
    Route::resource('fire', \App\Http\Controllers\FireController::class);
    Route::resource('video', \App\Http\Controllers\VideoController::class);
    Route::resource('phone', \App\Http\Controllers\PhoneController::class);
});



// выйти из профиля
Route::get('/logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('get-logout');

// главная страница
Route::get('/', [MainController::class, 'index'])->name('index');

// price
Route::get('/price', [MainController::class, 'price'])->name('price');

// contacts
Route::get('/contacts', [MainController::class, 'contacts'])->name('contacts');

// fire
Route::get('/fire', [MainController::class, 'fire'])->name('fire');

//popup
Route::get('/popup', [MainController::class, 'popup'])->name('popup');

//phone
Route::get('/phone', [MainController::class, 'phone'])->name('phone');

// video
Route::get('/video', [MainController::class, 'video'])->name('video');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
