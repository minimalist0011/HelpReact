$(function(){
    $('.menubg').click(function() {
        $('.menubg').fadeOut();
        $('.header ul').removeClass('opened');
    });
    $('.header .menu-button').click(function() {
        $('.menubg').fadeIn();
        $('.header ul').addClass('opened');
    });
});
