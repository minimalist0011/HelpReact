@extends('layouts.master')

@section('content')



        <div class="index-first-block">
            <img src="{{ asset('storage/index-first-block.png') }}">
            <div class="text">
                <p>О нашей компании</p>
                <button><a href="#informcomp">Перейти</a></button>
            </div>
        </div>

    <div class="index-about-block">
        <div id="informcomp" class="name">
            Компания “ИМПУЛЬС”
        </div>
        Наша компания предоставляет услуги по установке противопожарного оборудования, а так же занимается установкой охранного оборудования, с элементами видеонаблюдения, которое поможет вам защитить свое имужество от внешних случаев вторжения.
    </div>
    <div class="index-advantages-block">
        <div class="block-name">
            Плюсы работы с нами:
        </div>
        <div class="flex">
            <div class="item">
                <div class="name">
                    Противопожарное оборудование
                </div>
                <ul>
                    <li>Наша компания работает только с проверенными поставщиками оборудования;</li>
                    <li>Оборудование, которое мы устанавливаем, имеет пожизненое обслуживание;</li>
                    <li>Мы работаем на рынке уже 5 лет и имеем полное понимание того, что именно вам нажно и для каких целей;</li>
                    <li>Наша компания выполнила уже более 1500 заказов, самым большим заказом была установка противопожарного оборудования в  </li>
                </ul>
            </div>
            <div class="item">
                <div class="name">
                    Видеонаблюдение
                </div>
                <ul>
                    <li>Главными плюсами видеонаблюдения являются:</li>
                    <li>Безопасность вашего имещества;</li>
                    <li>Онлайн просмотр объекта с помощью приложения на телефоне;</li>
                    <li>Возможность вызова наряда, для экстренных случаев;</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="index-item">
        <div><img src="{{ asset('storage/item1.png') }}"></div>
        <div>
            <div class="name">
                Пожарное оборудование
            </div>
            <p>Мы предоставляем услуги по установке пожарного оборудования. Наша компания работает с лучшими компаниями по поставке оборудования. </p>
            <button><a href="{{ route('fire') }}">Больше информации</a></button>
        </div>
    </div>
    <div class="index-item2">
        <div>
            <div class="name">
                Видеонаблюдение
            </div>
            <p>Мы предоставляем услуги по установке оборудования видеонаблюдения. Камеры защитят Вас от внешних воздействий, а так же сохрянят ваше имущество в целости и сохранности. </p>
            <button><a href="{{ route('video') }}">Больше информации</a></button>
        </div>
        <div><img src="{{ asset('storage/item2.png') }}"></div>
    </div>
    <div class="index-contacts-block flex">
        <div class="contacts">
            <div class="name">
                Мы находимся по адресу:
            </div>
            @foreach($infos as $info)
            <p>{{ $info->adress }}</p>
            <p><span>Телефон:</span> {{ $info->phone }}</p>
            <p><span>Почта:</span> {{ $info->email }}</p>
            @endforeach
        </div>
        <div class="map">
            <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A22d95a6d71aad035cc4d7566d986c6b569521dde17397648d8d5479761e75ae0&amp;width=100%&amp;height=100%&amp;lang=ru_RU&amp;scroll=false"></script>
        </div>
    </div>
    <a href="#popup">
        <div type="button" class="callback-bt">
            <div class="text-call">
                <i class="fa fa-phone"></i>
                <span>Заказать<br>звонок</span>
            </div>
        </div>
    </a>
    <div id="popup" class="popup">
        <a href="#header" class="popup__area"></a>
        <div class="popup__body">
            <div class="popup__content">
                <a href="#header" class="popup__close">X</a>
                <div class="popup__title">Форма обратного звонка</div>
                <div class="popup__text">
                    <form method="GET" action="{{ route('popup') }}">
                        <div class="flex">
                            <input id="text" type="text" id="name" name="name" placeholder="Имя">
                            <input id="text" type="text" id="phone" name="phone" placeholder="Номер телефона" required>
                        </div>
                        <button type="submit" name="submit">Свяжитесь со мной</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
