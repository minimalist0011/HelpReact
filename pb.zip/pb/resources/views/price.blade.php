@extends('layouts.master')



@section('content')
    <div class="prices-block">
        <div class="name">
            Цены на наши услуги
        </div>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        <table>
            <tr>
                <th>Наименование услуги</th>
                <th>Стоимость услуги</th>
                <th>Гарантия</th>
            </tr>
            @foreach($prices as $price)
            <tr>
                <td>{{ $price->name }}</td>
                <td>{{ $price->price }}</td>
                <td>{{ $price->garante }}</td>
            </tr>
            @endforeach
        </table>
    </div>
    <div class="bottom-page-form">
        <div class="name">
            Свяжемся с вами в скором времени
        </div>
        <form method="GET" action="{{ route('phone') }}">
            <div class="flex">
                <input type="text" placeholder="Имя" name="name" id="name" required>
                <select name="type" id="type">
                    <option>Тип обращения</option>
                    <option>Установка видеонаблюдения</option>
                    <option>Установка противопожарной системы</option>
                    <option>Расчет стоимости</option>
                </select>
            </div>
            <div class="flex">
                <input type="text" name="email" id="email" placeholder="Почта">
                <input type="text" name="phone" id="phone" placeholder="Номер телефона" required>
            </div>
            <p>Выберите дату звонка</p>
            <input type="datetime-local" id="localdate" name="date"/>
            <select name="talk" id="talk">
                <option>Выберите как Вам удобно общаться</option>
                <option>Звонок</option>
                <option>Письмо на почту</option>
                <option>WhatsApp</option>
                <option>Viber</option>
            </select>
            <button type="submit">Свяжитесь со мной</button>
        </form>
    </div>
@endsection
