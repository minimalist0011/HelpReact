<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <title>Админка: @yield('title')</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="{{ asset('js/common.js') }}js/common.js"></script>
</head>
<body>
<header class="header flex">
    <div class="logo">
        <a href="{{ route('index') }}"><img src="{{ asset('storage/logo.png') }}"></a>
    </div>
        <a class="navbar-brand" href="{{ route('index') }}">Вернуться на сайт</a>

            @guest
                <ul>
                    <li>
                        <a href="{{ route('login') }}">Войти</a>
                    </li>
                </ul>
            @endguest

            @auth
                <ul>
                    <ul>
                        <li><a href="{{ route('fire.index') }}">Противопожарное оборудование</a></li>
                        <li><a href="{{ route('price.index') }}">Прайс-лист</a></li>
                        <li><a href="{{ route('video.index') }}">Видео оборудование</a></li>
                        <li><a href="{{ route('phone.index') }}">Заявки</a></li>
                    </ul>

                    <li><a href="{{ route('logout') }}">Выйти</a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                        </form>

                    </li>
                </ul>
            @endauth
</header>


            <div class="container-fluid">
                @yield('content')
            </div>
</body>
</html>
