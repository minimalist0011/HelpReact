@extends('auth.layouts.master')


@section('content')
    <div class="col-md-12">
        <h1>{{ $fire->name }}</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td>{{ $fire->id}}</td>
            </tr>
            <tr>
                <td>Название</td>
                <td>{{ $fire->name }}</td>
            </tr>
            <tr>
                <td>Фото</td>
                <td>{{ $fire->image }}</td>
            </tr>
            </tbody>
        </table>
    </div>
@endsection
