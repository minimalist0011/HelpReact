@extends('auth.layouts.master')

@isset($fire)
    @section('title', 'Редактировать оборудование ' . $fire->name)
@else
    @section('title', 'Создать оборудование')
@endisset

@section('content')
    <div class="col-md-12">
        @isset($fire)
            <h1>Редактировать оборудование <b>{{ $fire->name }}</b></h1>
        @else
            <h1>Добавить оборудование</h1>
        @endisset
        <form method="POST" enctype="multipart/form-data"
              @isset($fire)
              action="{{ route('fire.update', $fire) }}"
              @else
              action="{{ route('fire.store') }}"
            @endisset
        >
            <div>
                @isset($fire)
                    @method('PUT')
                @endisset
                @csrf
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Название</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" id="name"
                               value="@isset($fire){{ $fire->name }}@endisset">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Фото</label>
                    <div class="col-sm-6">
                        <input type="file" class="form-control" name="image" id="image"
                               value="@isset($fire){{ $fire->image }}@endisset">
                    </div>
                </div>
                <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
@endsection
