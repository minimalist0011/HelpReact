@extends('auth.layouts.master')

@section('title', 'Видео оборудование')

@section('content')
    <div class="col-md-12">
        <h1>Видео оборудование</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>#</th>
                <th>Название</th>
                <th>Фото</th>
            </tr>
            @foreach($videos as $video)
                <tr>
                    <td>{{ $video->id }}</td>
                    <td>{{ $video->name }}</td>
                    <td>{{ $video->image }}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <form action="{{ route('video.destroy', $video) }}" method="POST">
                                <a class="btn btn-success" type="button" href="{{ route('video.show', $video) }}">Открыть</a>
                                <!--<a class="btn btn-success" type="button" href="#">Skus</a>-->
                                <a class="btn btn-warning" type="button" href="{{ route('video.edit', $video) }}">Редактировать</a>
                                @csrf
                                @method('DELETE')
                                <input class="btn btn-danger" type="submit" value="Удалить"></form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <a class="btn btn-success" type="button" href="{{ route('video.create') }}">Добавить прайс</a>
    </div>
@endsection
