@extends('auth.layouts.master')

@isset($video)
    @section('title', 'Редактировать оборудование ' . $video->name)
@else
    @section('title', 'Создать оборудование')
@endisset

@section('content')
    <div class="col-md-12">
        @isset($video)
            <h1>Редактировать оборудование <b>{{ $video->name }}</b></h1>
        @else
            <h1>Добавить оборудование</h1>
        @endisset
        <form method="POST" enctype="multipart/form-data"
              @isset($video)
              action="{{ route('video.update', $video) }}"
              @else
              action="{{ route('video.store') }}"
            @endisset
        >
            <div>
                @isset($video)
                    @method('PUT')
                @endisset
                @csrf
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Название</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" id="name"
                               value="@isset($video){{ $video->name }}@endisset">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Фото</label>
                    <div class="col-sm-6">
                        <input type="file" class="form-control" name="image" id="image"
                               value="@isset($video){{ $video->image }}@endisset">
                    </div>
                </div>
                <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
@endsection
