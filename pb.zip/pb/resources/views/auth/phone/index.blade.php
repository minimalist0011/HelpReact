@extends('auth.layouts.master')

@section('title', 'Заявки')

@section('content')
    <div class="col-md-12">
        <h1>Заявки</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>#</th>
                <th>Имя</th>
                <th>Тип обращения</th>
                <th>Почта</th>
                <th>Телефон</th>
                <th>Время для связи</th>
                <th>Вид связи</th>
            </tr>
            @foreach($phones as $phone)
                <tr>
                    <td>{{ $phone->id }}</td>
                    <td>{{ $phone->name }}</td>
                    <td>{{ $phone->type }}</td>
                    <td>{{ $phone->email }}</td>
                    <td>{{ $phone->phone }}</td>
                    <td>{{ $phone->date }}</td>
                    <td>{{ $phone->talk }}</td>

                    <td>
                        <div class="btn-group" role="group">
                            <form action="{{ route('phone.destroy', $phone) }}" method="POST">
                                <a class="btn btn-success" type="button" href="{{ route('phone.show', $phone) }}">Открыть</a>
                                <!--<a class="btn btn-success" type="button" href="#">Skus</a>-->
                                <a class="btn btn-warning" type="button" href="{{ route('phone.edit', $phone) }}">Редактировать</a>
                                @csrf
                                @method('DELETE')
                                <input class="btn btn-danger" type="submit" value="Удалить"></form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

    </div>
@endsection
