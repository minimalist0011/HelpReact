@extends('auth.layouts.master')


    @section('title', 'Отметить как выполненное ' . $phone->name)


@section('content')
    <div class="col-md-12">
            <h1>Отметить заявку <b>{{ $phone->name }}</b></h1>
        <form method="POST" enctype="multipart/form-data"
              action="{{ route('phone.update', $phone) }}">
            <div>
                @csrf
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Отметить как выполненное </label>
                    <div class="col-sm-6">
                        <input type="checkbox" class="form-control" name="name" id="name"
                               value="@isset($price){{ $price->done }}@endisset">
                    </div>
                </div>
               <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
@endsection
