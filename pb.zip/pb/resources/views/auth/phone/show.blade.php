@extends('auth.layouts.master')


@section('content')
    <div class="col-md-12">
        <h1>{{ $phone->name }}</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td>{{ $phone->id}}</td>
            </tr>
            <tr>
                <td>Имя</td>
                <td>{{ $phone->name }}</td>
            </tr>
            <tr>
                <td>Тип обращения</td>
                <td>{{ $phone->type }}</td>
            </tr>
            <tr>
                <td>Почта</td>
                <td>{{ $phone->email }}</td>
            </tr>
            <tr>
                <td>Телефон</td>
                <td>{{ $phone->phone }}</td>
            </tr>
            <tr>
                <td>Время для связи</td>
                <td>{{ $phone->date }}</td>
            </tr>
            <tr>
                <td>Вид связи</td>
                <td>{{ $phone->talk }}</td>
            </tr>
            </tbody>
        </table>
    </div>
@endsection
