@extends('auth.layouts.master')

@isset($price)
    @section('title', 'Редактировать прайс ' . $price->name)
@else
    @section('title', 'Создать прайс')
@endisset

@section('content')
    <div class="col-md-12">
        @isset($price)
            <h1>Редактировать прайс <b>{{ $price->name }}</b></h1>
        @else
            <h1>Добавить прайс</h1>
        @endisset
        <form method="POST" enctype="multipart/form-data"
              @isset($price)
              action="{{ route('price.update', $price) }}"
              @else
              action="{{ route('price.store') }}"
            @endisset
        >
            <div>
                @isset($price)
                    @method('PUT')
                @endisset
                @csrf
                <div class="input-group row">
                    <label for="code" class="col-sm-2 col-form-label">Название </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" id="name"
                               value="@isset($price){{ $price->name }}@endisset">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="name" class="col-sm-2 col-form-label">Прайс </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="price" id="price"
                               value="@isset($price){{ $price->price }}@endisset">
                    </div>
                </div>
                <br>
                <div class="input-group row">
                    <label for="category_id" class="col-sm-2 col-form-label">Гарантия </label>
                    <input type="text" class="form-control" name="garante" id="garante"
                           value="@isset($price){{ $price->garante }}@endisset">
                    <div class="col-sm-6">

                    </div>
                </div>
                    <br>

                <button class="btn btn-success">Сохранить</button>
            </div>
        </form>
    </div>
@endsection
