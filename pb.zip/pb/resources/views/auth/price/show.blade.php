@extends('auth.layouts.master')


@section('content')
    <div class="col-md-12">
        <h1>{{ $price->name }}</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>Поле</th>
                <th>Значение</th>
            </tr>
            <tr>
                <td>ID</td>
                <td>{{ $price->id}}</td>
            </tr>
            <tr>
                <td>Название</td>
                <td>{{ $price->name }}</td>
            </tr>
            <tr>
                <td>Прайс</td>
                <td>{{ $price->price }}</td>
            </tr>
            <tr>
                <td>Гарантия</td>
                <td>{{ $price->garante }}</td>
            </tr>
            </tbody>
        </table>
    </div>
@endsection
