@extends('auth.layouts.master')

@section('title', 'Прайс')

@section('content')
    <div class="col-md-12">
        <h1>Прайс</h1>
        <table class="table">
            <tbody>
            <tr>
                <th>#</th>
                <th>Название</th>
                <th>Прайс</th>
                <th>Гарантия</th>
            </tr>
            @foreach($prices as $price)
                <tr>
                    <td>{{ $price->id }}</td>
                    <td>{{ $price->name }}</td>
                    <td>{{ $price->price }}</td>
                    <td>{{ $price->garante }}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <form action="{{ route('price.destroy', $price) }}" method="POST">
                                <a class="btn btn-success" type="button" href="{{ route('price.show', $price) }}">Открыть</a>
                                <!--<a class="btn btn-success" type="button" href="#">Skus</a>-->
                                <a class="btn btn-warning" type="button" href="{{ route('price.edit', $price) }}">Редактировать</a>
                                @csrf
                                @method('DELETE')
                                <input class="btn btn-danger" type="submit" value="Удалить"></form>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <a class="btn btn-success" type="button" href="{{ route('price.create') }}">Добавить прайс</a>
    </div>
@endsection
