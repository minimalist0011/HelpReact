@extends('layouts.master')

@section('content')

    <div class="index-contacts-block inner">
        <div class="contacts">
            <div class="name">
                Мы находимся по адресу:
            </div>
            @foreach($infos as $info)
            <p>{{ $info->adress }}</p>
            <p><span>Телефон:</span>{{ $info->phone }}</p>
            <p><span>Почта:</span> {{ $info->email }}</p>
            @endforeach
        </div>
    </div>
    <div class="contacts-map">
        <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A22d95a6d71aad035cc4d7566d986c6b569521dde17397648d8d5479761e75ae0&amp;width=100%&amp;height=100%&amp;lang=ru_RU&amp;scroll=false"></script>
    </div>
@endsection
