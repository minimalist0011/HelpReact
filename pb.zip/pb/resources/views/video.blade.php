@extends('layouts.master')

@section('content')
    <div class="index-first-block">
        <img src="{{  asset('storage/video/service2.png')  }}">
        <div class="text">
            <p class="other">Видеонаблюдение</p>
        </div>
    </div>
    <div class="services-block flex">
        <div class="list">
            <div class="name">
                Виды выполняемых работ
            </div>
            <p>Ниже представлены варианты мест где устанавливаются камеры:</p>
            <div class="flex other">
                @foreach($videos as $video)
                    <div class="item">
                        <img src="{{  asset("storage/$video->image")  }}">
                        <p>{{ $video->name }}</p>
                    </div>
                @endforeach
            </div>
        </div>
        <div class="main-item">
            <img src="{{  asset('storage/video/image2.png')  }}">
            <div class="text">
                <div class="name">
                    Предоставляемые виды работ
                </div>
                Наша компания предоставляет возможность реализации установки: автоматического пожаротушения, пожарной сигнализации, внутреннего противопожарного водопровода, монтаж системы оповещения, а так же занимаемся пректированием систем тушения, под каждый заказ.
            </div>
        </div>
    </div>
    <div class="bottom-page-form">
        <div class="name">
            Свяжемся с вами в скором времени
        </div>
        <form method="GET" action="{{ route('phone') }}">
            <div class="flex">
                <input type="text" placeholder="Имя" name="name" id="name" required>
                <select name="type" id="type">
                    <option>Тип обращения</option>
                    <option>Установка видеонаблюдения</option>
                    <option>Установка противопожарной системы</option>
                    <option>Расчет стоимости</option>
                </select>
            </div>
            <div class="flex">
                <input type="text" name="email" id="email" placeholder="Почта">
                <input type="text" name="phone" id="phone" placeholder="Номер телефона" required>
            </div>
            <p>Выберите дату звонка</p>
            <input type="datetime-local" id="localdate" name="date"/>
            <select name="talk" id="talk">
                <option>Выберите как Вам удобно общаться</option>
                <option>Звонок</option>
                <option>Письмо на почту</option>
                <option>WhatsApp</option>
                <option>Viber</option>
            </select>
            <button type="submit">Свяжитесь со мной</button>
        </form>
    </div>
@endsection
